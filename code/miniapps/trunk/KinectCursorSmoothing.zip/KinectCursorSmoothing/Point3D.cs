﻿
namespace KinectCursorSmoothing
{
    public class Point3D
    {
        public float X;
        public float Y;
        public float Z;

        public Point3D() { }

        public Point3D(float x, float y, float z)
        {
            X = x;
            Y = x;
            Z = z;
        }
    }
}
